"""LSI Dashboard — главная страница: текущий статус, основной график, вклад модулей."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from utils import (
    COLOR_RED,
    LSI_THRESHOLDS,
    filter_window,
    first_present,
    latest_row,
    load_wide_lsi,
    lsi_column,
    module_share,
    status_band_shapes,
    status_for,
)

st.set_page_config(
    page_title="LSI — Liquidity Stress Index",
    page_icon="📈",
    layout="wide",
)

st.title("Liquidity Stress Index — главная")
st.caption("Система раннего предупреждения стресса ликвидности денежного рынка РФ (M1–M5 → LSI 0–100).")

try:
    wide = load_wide_lsi()
except FileNotFoundError as e:
    st.error(str(e))
    st.info(
        "Подсказка: запустите экспорт в конце `final.ipynb` (см. `dashboard/README.md`) — "
        "будет создан файл `dashboard/data/wide_lsi.csv`."
    )
    st.stop()

LSI = lsi_column(wide)
last = latest_row(wide)

# --- KPI / алерт ---
c1, c2, c3, c4 = st.columns([1.2, 1, 1, 2.0])
if last is not None:
    val = float(last[LSI])
    label, emoji, color = status_for(val)
    delta = None
    sub = wide[wide[LSI].notna()].tail(8)
    if len(sub) >= 2:
        delta = float(sub[LSI].iloc[-1] - sub[LSI].iloc[-2])
    c1.metric(
        label=f"LSI ({LSI})",
        value=f"{val:0.1f} / 100",
        delta=None if delta is None else f"{delta:+0.2f} к пред. дню",
    )
    c2.markdown(
        f"### {emoji} **{label}**\n"
        f"<small>пороги: 0–{LSI_THRESHOLDS[0]:.0f} зелёный / "
        f"{LSI_THRESHOLDS[0]:.0f}–{LSI_THRESHOLDS[1]:.0f} жёлтый / "
        f"{LSI_THRESHOLDS[1]:.0f}–100 красный</small>",
        unsafe_allow_html=True,
    )
    c3.metric("Дата наблюдения", last["date"].strftime("%Y-%m-%d"))
    if "_m4_tax_kick" in wide.columns and pd.notna(last.get("_m4_tax_kick")):
        c4.metric("M4 tax-kick (post-hoc)", f"{float(last['_m4_tax_kick']):0.2f} пунктов LSI")
else:
    st.warning("В данных нет ни одной строки с LSI.")
    st.stop()

st.divider()

# --- Контролы периода ---
left, right = st.columns([3, 1])
dmin, dmax = wide["date"].min(), wide["date"].max()
default_from = max(dmin, dmax - pd.Timedelta(days=365 * 4))
date_range = right.date_input(
    "Период",
    value=(default_from.date(), dmax.date()),
    min_value=dmin.date(),
    max_value=dmax.date(),
)
if isinstance(date_range, tuple) and len(date_range) == 2:
    a, b = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
else:
    a, b = default_from, dmax
view = filter_window(wide, (a, b))

# --- Главный график LSI ---
fig = go.Figure()
y_cols = first_present(view, ["LSI_teacher", "LSI_lgbm_tuned", "LSI_lgbm_tuned_tax_adj",
                              "LSI_ensemble", "LSI_ensemble_tax_adj", "LSI_lgbm_huber"])
palette = {
    "LSI_teacher":             ("#9aa3ad", "dot"),
    "LSI_ensemble":            ("#1f4e79", "solid"),
    "LSI_ensemble_tax_adj":    ("#0a3d62", "dash"),
    "LSI_lgbm_huber":          ("#1565c0", "solid"),
    "LSI_lgbm_tuned":          ("#0f5fa6", "solid"),
    "LSI_lgbm_tuned_tax_adj":  ("#0a3d62", "dash"),
}
for c in y_cols:
    color, dash = palette.get(c, ("#1f4e79", "solid"))
    fig.add_trace(go.Scatter(
        x=view["date"], y=view[c], name=c, mode="lines",
        line=dict(color=color, width=2, dash=dash),
        hovertemplate="%{x|%Y-%m-%d}<br>" + c + "=%{y:.2f}<extra></extra>",
    ))

# Полосы алертов и порог красного.
fig.update_layout(shapes=status_band_shapes())
fig.add_hline(y=LSI_THRESHOLDS[1], line=dict(color=COLOR_RED, width=1, dash="dot"),
              annotation_text="порог 70", annotation_position="top left")

fig.update_layout(
    title=f"LSI — {LSI} (выбранный период)",
    xaxis_title="", yaxis_title="LSI Score (0–100)",
    yaxis=dict(range=[0, 100]),
    hovermode="x unified",
    legend=dict(orientation="h", yanchor="bottom", y=1.01, x=0),
    height=520,
    margin=dict(l=10, r=10, t=70, b=20),
)
left.plotly_chart(fig, width='stretch')

# --- Вклад модулей и таблица последних дней ---
st.subheader("Вклад модулей в текущий LSI")
share = module_share(view if not view.empty else wide)
col_a, col_b = st.columns([1.4, 1])
if not share.empty:
    bar = go.Figure(go.Bar(
        x=share["share"] * 100, y=share["module"], orientation="h",
        marker_color=["#0a3d62", "#1565c0", "#2e7cb8", "#5b97c8", "#9bc1da"][: len(share)],
        text=[f"{v*100:0.1f}%" for v in share["share"]], textposition="outside",
    ))
    bar.update_layout(
        height=320, margin=dict(l=10, r=10, t=10, b=10),
        xaxis_title="Доля модуля в текущем сигнале (по последним MAD/флагам)",
        yaxis=dict(autorange="reversed"),
    )
    col_a.plotly_chart(bar, width='stretch')
else:
    col_a.info("Не нашёл MAD-/flag-колонок модулей для оценки вклада.")

cols_show = ["date"] + first_present(
    view,
    [
        LSI, "LSI_teacher",
        "_m4_tax_kick",
        "m5_liquidity_deficit", "m5_liquidity_deficit_ex_corr",
        "m2_Cover_ratio", "m3_cover_ratio", "m1_shift_mad",
    ],
)
last_n = view[cols_show].dropna(subset=[LSI]).tail(15).copy()
last_n["date"] = last_n["date"].dt.strftime("%Y-%m-%d")
last_n["статус"] = last_n[LSI].apply(lambda v: status_for(float(v))[1] + " " + status_for(float(v))[0])
col_b.markdown("**Последние 15 дней:**")
col_b.dataframe(last_n.set_index("date"), width='stretch', height=320)

with st.expander("О пороговых значениях алертов"):
    st.markdown(
        f"""
        Согласно ТЗ, статус определяется по диапазонам LSI:
        - 🟢 **Зелёный** — `0 ≤ LSI < {LSI_THRESHOLDS[0]:.0f}` (низкий стресс),
        - 🟡 **Жёлтый** — `{LSI_THRESHOLDS[0]:.0f} ≤ LSI < {LSI_THRESHOLDS[1]:.0f}` (повышенное напряжение),
        - 🔴 **Красный** — `LSI ≥ {LSI_THRESHOLDS[1]:.0f}` (сильный стресс).

        Колонка LSI выбирается автоматически в порядке предпочтения: `LSI_lgbm_tuned_tax_adj` → `LSI_lgbm_tuned`
        → `LSI_ensemble_tax_adj` → `LSI_ensemble` → `LSI_lgbm_huber` → `LSI_teacher`.
        """
    )
