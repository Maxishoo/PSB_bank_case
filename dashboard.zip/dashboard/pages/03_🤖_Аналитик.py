"""Страница: аналитический комментарий + чат-заготовка (бонус из ТЗ).

Базовая (RAG-friendly) версия: формирует структурированный текстовый разбор
текущего состояния по числам из системы. Если у вас есть ключ от LLM API
(OpenAI / GigaChat / Yandex GPT), подставьте его в `_call_llm()` ниже —
получите автокомментарий и чат «Аналитик».
"""
from __future__ import annotations

import os

import numpy as np
import pandas as pd
import streamlit as st

from utils import (
    LSI_THRESHOLDS,
    filter_window,
    first_present,
    latest_row,
    load_wide_lsi,
    lsi_column,
    module_share,
    status_for,
)

st.set_page_config(page_title="Аналитик (LLM)", page_icon="🤖", layout="wide")
st.title("LLM-аналитик: автокомментарий и чат")
st.caption("Базовая версия — формирует разбор по числам системы (RAG по `wide_lsi`).")

wide = load_wide_lsi()
LSI = lsi_column(wide)


SYSTEM_PROMPT = (
    "Ты — аналитик казначейства банка. Отвечай кратко, по числам. "
    "Используй только данные, переданные в промпте. "
    "Если в данных нет ответа — так и скажи, не выдумывай."
)


def _resolve_provider() -> tuple[str, str, str] | None:
    """Возвращает (provider, base_url, model) или None.

    Приоритет: явный LLM_PROVIDER → DeepSeek → OpenAI.
    DeepSeek и OpenAI оба используют openai-совместимый клиент.
    """
    explicit = (os.getenv("LLM_PROVIDER") or "").lower().strip()

    if explicit == "deepseek" or (not explicit and os.getenv("DEEPSEEK_API_KEY")):
        key = os.getenv("DEEPSEEK_API_KEY")
        if not key:
            return None
        return (
            "deepseek",
            os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1"),
            os.getenv("DEEPSEEK_MODEL", "deepseek-chat"),
        )

    if explicit == "openai" or (not explicit and os.getenv("OPENAI_API_KEY")):
        key = os.getenv("OPENAI_API_KEY")
        if not key:
            return None
        return (
            "openai",
            os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
            os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        )
    return None


def _call_llm(prompt: str) -> str | None:
    """Универсальный вызов через openai-клиент. Поддерживает DeepSeek и OpenAI."""
    cfg = _resolve_provider()
    if cfg is None:
        return None
    provider, base_url, model = cfg

    api_key = (
        os.getenv("DEEPSEEK_API_KEY") if provider == "deepseek" else os.getenv("OPENAI_API_KEY")
    )
    try:
        from openai import OpenAI

        client = OpenAI(api_key=api_key, base_url=base_url)
        rsp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            stream=False,
        )
        return rsp.choices[0].message.content
    except Exception as e:
        return f"[LLM ({provider}/{model}) недоступен: {e}]"


def _build_context(df: pd.DataFrame, n_days: int = 30) -> str:
    last = latest_row(df)
    if last is None:
        return "Нет данных."
    val = float(last[LSI])
    label, emoji, _ = status_for(val)

    # окно для сводки
    end = pd.Timestamp(last["date"])
    start = end - pd.Timedelta(days=n_days)
    win = filter_window(df, (start, end))

    share = module_share(win)
    share_text = "; ".join(
        f"{r['module']}: {r['share']*100:0.1f}%" for _, r in share.iterrows()
    ) if not share.empty else "n/a"

    cols = first_present(
        win,
        [LSI, "LSI_teacher", "_m4_tax_kick",
         "m5_liquidity_deficit", "m2_Cover_ratio", "m3_cover_ratio",
         "m1_shift_mad", "m1_ruo_mad"],
    )
    desc = win[cols].describe().T[["mean", "std", "min", "max"]].round(3).to_string()

    return (
        f"Дата: {last['date'].date()}\n"
        f"LSI = {val:0.2f} → статус {emoji} {label} (пороги {LSI_THRESHOLDS}).\n"
        f"Окно для сводки: последние {n_days} дн.\n"
        f"Вклад модулей (по последним MAD/флагам): {share_text}.\n"
        f"\nСтатистики ключевых рядов в окне:\n{desc}\n"
    )


# --- Автокомментарий ---
st.subheader("Автокомментарий по текущему состоянию")
n_days = st.slider("Окно сводки, дней", 7, 180, 30, step=1)
ctx = _build_context(wide, n_days=n_days)
st.code(ctx, language="text")

prompt = (
    "Ниже — текущее состояние LSI и сводные статистики по модулям M1–M5 "
    "(M4 учитывается как post-hoc tax-kick). Дай аналитический комментарий: "
    "что происходит с ликвидностью, какие модули давят, что ждать в ближайшую "
    "неделю с учётом налогового календаря и аукционов ОФЗ. Кратко (5–8 пунктов).\n\n" + ctx
)
# Бейдж активного провайдера.
_cfg = _resolve_provider()
if _cfg is None:
    st.warning(
        "LLM не подключён. Поддерживаются **DeepSeek** (`DEEPSEEK_API_KEY`) и "
        "**OpenAI** (`OPENAI_API_KEY`). Без ключа работает «структурный» разбор по числам выше."
    )
else:
    st.success(f"Активный LLM: **{_cfg[0]}** · модель `{_cfg[2]}` · `{_cfg[1]}`")

if st.button("Сгенерировать комментарий через LLM"):
    out = _call_llm(prompt)
    if out is None:
        st.info(
            "LLM не подключён (нет ключа). Структурный разбор по числам показан выше."
        )
    else:
        st.markdown(out)

st.divider()

# --- Чат ---
st.subheader("Чат «Аналитик» (RAG по числам системы)")
if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

for role, msg in st.session_state["chat_history"]:
    with st.chat_message(role):
        st.markdown(msg)

user_q = st.chat_input("Спросите про период / эпизод / модуль…")
if user_q:
    st.session_state["chat_history"].append(("user", user_q))
    with st.chat_message("user"):
        st.markdown(user_q)

    full_prompt = (
        "Ты отвечаешь на вопрос аналитика, опираясь только на следующие данные:\n\n"
        + _build_context(wide, n_days=180)
        + f"\nВопрос пользователя: {user_q}\nОтветь по числам из контекста, кратко."
    )
    answer = _call_llm(full_prompt) or (
        "LLM не подключён. Кратко по числам: см. сводку выше — максимумы/минимумы "
        "за окно и вклад модулей. Чтобы включить LLM, задайте перед запуском Streamlit "
        "одну из переменных окружения: `DEEPSEEK_API_KEY` или `OPENAI_API_KEY`."
    )
    st.session_state["chat_history"].append(("assistant", answer))
    with st.chat_message("assistant"):
        st.markdown(answer)
