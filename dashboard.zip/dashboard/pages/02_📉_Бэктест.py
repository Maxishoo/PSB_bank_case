"""Страница: бэктест на исторических стресс-эпизодах из ТЗ."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from utils import (
    LSI_THRESHOLDS,
    COLOR_RED,
    filter_window,
    first_present,
    load_wide_lsi,
    lsi_column,
    status_band_shapes,
    status_for,
)

st.set_page_config(page_title="Бэктест LSI", page_icon="📉", layout="wide")
st.title("Бэктест: исторические стресс-эпизоды")
st.caption("По ТЗ обязательны эпизоды декабрь 2014, февраль–март 2022, август 2023.")

wide = load_wide_lsi()
LSI = lsi_column(wide)

EPISODES = [
    ("Декабрь 2014 — рост ключевой ставки", "2014-11-15", "2015-02-15"),
    ("Февраль–март 2022 — геополитический шок", "2022-02-01", "2022-04-30"),
    ("Август 2023 — давление на рубль", "2023-07-15", "2023-09-30"),
]


def _episode_chart(name: str, start: str, end: str) -> None:
    a = pd.Timestamp(start)
    b = pd.Timestamp(end)
    if a > wide["date"].max() or b < wide["date"].min():
        st.warning(f"{name}: данных за этот период в датасете нет.")
        return

    view = filter_window(wide, (a, b))
    if view.empty or view[LSI].notna().sum() < 3:
        st.warning(f"{name}: мало точек в окне ({a.date()}…{b.date()}).")
        return

    cols = first_present(view, [LSI, "LSI_teacher", "LSI_ensemble", "LSI_lgbm_tuned"])
    fig = go.Figure()
    palette = {
        LSI: ("#0a3d62", "solid"),
        "LSI_teacher": ("#9aa3ad", "dot"),
        "LSI_ensemble": ("#1f4e79", "solid"),
        "LSI_lgbm_tuned": ("#1565c0", "solid"),
    }
    for c in cols:
        col, dash = palette.get(c, ("#1f4e79", "solid"))
        fig.add_trace(go.Scatter(
            x=view["date"], y=view[c], name=c, mode="lines",
            line=dict(color=col, width=2 if c == LSI else 1.4, dash=dash),
            hovertemplate="%{x|%Y-%m-%d}<br>" + c + "=%{y:.2f}<extra></extra>",
        ))

    fig.update_layout(shapes=status_band_shapes())
    fig.add_hline(
        y=LSI_THRESHOLDS[1], line=dict(color=COLOR_RED, width=1, dash="dot"),
        annotation_text="порог 70", annotation_position="top left",
    )
    fig.update_layout(
        title=name,
        xaxis_title="", yaxis_title="LSI",
        yaxis=dict(range=[0, 100]),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0),
        margin=dict(l=10, r=10, t=60, b=20), height=380,
    )
    st.plotly_chart(fig, width='stretch')

    # Сводка эпизода: пики, длительность красного.
    sub = view[[LSI]].dropna()
    days_red = int((sub[LSI] >= LSI_THRESHOLDS[1]).sum())
    days_yel = int(((sub[LSI] >= LSI_THRESHOLDS[0]) & (sub[LSI] < LSI_THRESHOLDS[1])).sum())
    peak = float(sub[LSI].max()) if len(sub) else float("nan")
    peak_dt = view.loc[sub[LSI].idxmax(), "date"] if len(sub) else None
    cur_label, emoji, _ = status_for(peak)

    a1, a2, a3, a4 = st.columns(4)
    a1.metric("Пик LSI", f"{peak:0.1f}", delta=cur_label)
    a2.metric("Дата пика", peak_dt.strftime("%Y-%m-%d") if peak_dt is not None else "—")
    a3.metric("Дней 🔴 (≥70)", f"{days_red}")
    a4.metric("Дней 🟡 (40–70)", f"{days_yel}")
    st.divider()


for name, start, end in EPISODES:
    _episode_chart(name, start, end)

# --- Кастомный эпизод ---
st.subheader("Свой период")
c1, c2 = st.columns(2)
custom_a = c1.date_input("От", value=pd.Timestamp("2024-01-01").date(), key="custom_a")
custom_b = c2.date_input("До", value=wide["date"].max().date(), key="custom_b")
if pd.Timestamp(custom_a) < pd.Timestamp(custom_b):
    _episode_chart("Произвольный период", str(custom_a), str(custom_b))
