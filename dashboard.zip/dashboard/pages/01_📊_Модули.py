"""Страница: графики по каждому модулю M1–M5."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from utils import filter_window, first_present, load_wide_lsi

st.set_page_config(page_title="Модули M1–M5", page_icon="📊", layout="wide")
st.title("Модули M1–M5: исходные ряды и MAD-сигналы")

wide = load_wide_lsi()
dmin, dmax = wide["date"].min(), wide["date"].max()
default_from = max(dmin, dmax - pd.Timedelta(days=365 * 5))
date_range = st.date_input(
    "Период",
    value=(default_from.date(), dmax.date()),
    min_value=dmin.date(),
    max_value=dmax.date(),
)
if isinstance(date_range, tuple) and len(date_range) == 2:
    view = filter_window(wide, (pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])))
else:
    view = wide.copy()

MODULES: list[tuple[str, str, list[tuple[str, str]]]] = [
    (
        "M1 — Усреднение обязательных резервов",
        "Спред усреднения и RUONIA + MAD-сигналы.",
        [
            ("m1_shift", "Спред усреднения (факт − обязат.)"),
            ("m1_ruo", "RUONIA"),
            ("m1_shift_mad", "MAD: спред усреднения"),
            ("m1_ruo_mad", "MAD: RUONIA"),
        ],
    ),
    (
        "M2 — Аукционы репо ЦБ (7 дн.)",
        "Cover ratio, спред ставки, ключевая ставка ЦБ.",
        [
            ("m2_Ключевая_ставка", "Ключевая ставка"),
            ("m2_Cover_ratio", "Cover ratio репо"),
            ("m2_Rate_spread", "Спред ставки репо к ключевой"),
            ("m2_MAD_score_cover", "MAD: cover ratio репо"),
        ],
    ),
    (
        "M3 — Размещение ОФЗ (Минфин)",
        "Cover ratio, доходность, MAD-сигналы.",
        [
            ("m3_cover_ratio", "Cover ratio ОФЗ"),
            ("m3_yield_avg", "Средневзвеш. доходность"),
            ("m3_yield_spread", "Спред доходности к кривой"),
            ("m3_mad_score_cover", "MAD: cover ratio ОФЗ"),
        ],
    ),
    (
        "M4 — Налоговый период (post-hoc)",
        "Учитывается отдельно как добавка к LSI (`_m4_tax_kick`), не как признак модели.",
        [
            ("m4_tax_event_weight", "Вес налоговых событий дня"),
            ("m4_n_important", "Кол-во важных событий"),
            ("_m4_tax_kick", "Tax-kick (добавка к LSI, post-hoc)"),
        ],
    ),
    (
        "M5 — Средства казначейства / ликвидность ЦБ",
        "Структурный баланс ликвидности и MAD-сигналы.",
        [
            ("m5_liquidity_deficit", "Дефицит/профицит ликвидности"),
            ("m5_liquidity_deficit_ex_corr", "То же без корсчётов"),
            ("m5_treasury_pressure", "Изменение деф. (treasury pressure)"),
            ("m5_MAD_score_liquidity_deficit", "MAD: дефицит ликвидности"),
            ("m5_MAD_score_treasury_pressure", "MAD: treasury pressure"),
        ],
    ),
]


def _plot_module(title: str, desc: str, cols: list[tuple[str, str]]) -> None:
    have = [(c, lbl) for c, lbl in cols if c in view.columns and view[c].notna().any()]
    if not have:
        st.warning(f"{title}: нет данных в выбранном окне.")
        return
    n = len(have)
    fig = make_subplots(rows=n, cols=1, shared_xaxes=True, vertical_spacing=0.04)
    for i, (c, lbl) in enumerate(have, start=1):
        s = view[c]
        fig.add_trace(
            go.Scatter(
                x=view["date"], y=s, mode="lines",
                name=lbl,
                line=dict(width=1.6, color="#1f4e79"),
                hovertemplate="%{x|%Y-%m-%d}<br>" + c + "=%{y:.4f}<extra></extra>",
            ),
            row=i, col=1,
        )
        fig.update_yaxes(title_text=lbl, row=i, col=1)
    fig.update_layout(
        title=title, height=210 * n + 40, showlegend=False,
        hovermode="x unified", margin=dict(l=10, r=10, t=60, b=20),
    )
    st.markdown(f"**{title}** — {desc}")
    st.plotly_chart(fig, width='stretch')


tabs = st.tabs(["M1", "M2", "M3", "M4", "M5"])
for tab, (title, desc, cols) in zip(tabs, MODULES):
    with tab:
        _plot_module(title, desc, cols)

with st.expander("Какие колонки доступны в датасете"):
    cols_by_mod = {
        "M1": [c for c in view.columns if c.startswith("m1_")],
        "M2": [c for c in view.columns if c.startswith("m2_")],
        "M3": [c for c in view.columns if c.startswith("m3_")],
        "M4": [c for c in view.columns if c.startswith("m4_")] + first_present(view, ["_m4_tax_kick"]),
        "M5": [c for c in view.columns if c.startswith("m5_")],
        "LSI": [c for c in view.columns if c.startswith("LSI_")],
    }
    for k, v in cols_by_mod.items():
        st.markdown(f"**{k}** ({len(v)}): " + (", ".join(v) if v else "—"))
