"""Загрузка данных и общие хелперы для дашборда LSI.

Дашборд читает один CSV/parquet — `data/wide_lsi.csv` (или .parquet).
Файл получается экспортом `wide_lsi` из `final.ipynb` (см. README).
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import streamlit as st

DASHBOARD_DIR = Path(__file__).resolve().parent
DATA_DIR = DASHBOARD_DIR / "data"

# Цвета алертов из ТЗ.
COLOR_GREEN = "#1f9d55"
COLOR_YELLOW = "#e0a800"
COLOR_RED = "#c82333"
COLOR_NEUTRAL = "#5c6770"

LSI_THRESHOLDS = (40.0, 70.0)  # green < 40, yellow 40-70, red >= 70


@st.cache_data(show_spinner=False)
def load_wide_lsi() -> pd.DataFrame:
    """Читает экспортированный wide_lsi (CSV/parquet) и приводит date к datetime."""
    parquet = DATA_DIR / "wide_lsi.parquet"
    csv = DATA_DIR / "wide_lsi.csv"
    if parquet.exists():
        df = pd.read_parquet(parquet)
    elif csv.exists():
        df = pd.read_csv(csv)
    else:
        raise FileNotFoundError(
            "Не найден файл данных. Экспортируйте `wide_lsi` из final.ipynb в "
            f"{csv} (см. README)."
        )
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        df = df.sort_values("date").reset_index(drop=True)
    return df


def lsi_column(df: pd.DataFrame) -> str:
    """Выбирает доступную колонку LSI (приоритет — финальный продукт)."""
    for c in (
        "LSI_lgbm_tuned_tax_adj",
        "LSI_lgbm_tuned",
        "LSI_ensemble_tax_adj",
        "LSI_ensemble",
        "LSI_lgbm_huber",
        "LSI_teacher",
    ):
        if c in df.columns:
            return c
    raise KeyError("В данных нет ни одной колонки LSI_*.")


def status_for(value: float) -> tuple[str, str, str]:
    """Возвращает (status, emoji, color) по значению LSI."""
    if value is None or not np.isfinite(value):
        return "нет данных", "⚪", COLOR_NEUTRAL
    lo, hi = LSI_THRESHOLDS
    if value < lo:
        return "Зелёный", "🟢", COLOR_GREEN
    if value < hi:
        return "Жёлтый", "🟡", COLOR_YELLOW
    return "Красный", "🔴", COLOR_RED


def status_band_shapes() -> list[dict]:
    """Горизонтальные полосы алертов для plotly (для y∈[0,100])."""
    lo, hi = LSI_THRESHOLDS
    return [
        dict(type="rect", xref="paper", x0=0, x1=1, y0=0, y1=lo,
             fillcolor=COLOR_GREEN, opacity=0.06, line_width=0, layer="below"),
        dict(type="rect", xref="paper", x0=0, x1=1, y0=lo, y1=hi,
             fillcolor=COLOR_YELLOW, opacity=0.07, line_width=0, layer="below"),
        dict(type="rect", xref="paper", x0=0, x1=1, y0=hi, y1=100,
             fillcolor=COLOR_RED, opacity=0.07, line_width=0, layer="below"),
    ]


def filter_window(df: pd.DataFrame, dates: tuple[pd.Timestamp, pd.Timestamp]) -> pd.DataFrame:
    """Фильтрация по диапазону дат с защитой от tz-naive."""
    a, b = pd.Timestamp(dates[0]), pd.Timestamp(dates[1])
    return df[(df["date"] >= a) & (df["date"] <= b)].copy()


def first_present(df: pd.DataFrame, candidates: Iterable[str]) -> list[str]:
    return [c for c in candidates if c in df.columns]


def latest_row(df: pd.DataFrame) -> pd.Series | None:
    """Последняя строка с непустым LSI."""
    if df.empty:
        return None
    col = lsi_column(df)
    sub = df[df[col].notna()]
    if sub.empty:
        return None
    return sub.iloc[-1]


def module_share(df: pd.DataFrame) -> pd.DataFrame:
    """Грубая оценка вклада модулей в текущий LSI: норма последних значений MAD-фич."""
    cands = {
        "M1 — Усреднение резервов": ("m1_shift_mad", "m1_ruo_mad"),
        "M2 — Репо ЦБ":             ("m2_MAD_score_cover", "m2_MAD_score_rate_spread"),
        "M3 — ОФЗ":                 ("m3_mad_score_cover", "m3_mad_score_yield_spread"),
        "M4 — Налоги (post-hoc)":   ("_m4_tax_kick",),
        "M5 — Казначейство":        ("m5_MAD_score_treasury_pressure", "m5_MAD_score_liquidity_deficit"),
    }
    if df.empty:
        return pd.DataFrame(columns=["module", "score"])
    last = df.iloc[-1]
    rows = []
    for name, cols in cands.items():
        vals = [abs(float(last[c])) for c in cols if c in df.columns and pd.notna(last[c])]
        if not vals:
            continue
        rows.append({"module": name, "score": float(np.mean(vals))})
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["share"] = out["score"] / out["score"].sum() if out["score"].sum() > 0 else 0.0
    return out.sort_values("share", ascending=False).reset_index(drop=True)
