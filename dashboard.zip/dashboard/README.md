# LSI Dashboard (Streamlit)

Интерактивный дашборд по системе раннего предупреждения стресса ликвидности рублёвого денежного рынка (см. `тз.docx`).

## Структура

```
dashboard/
├─ app.py                         # Главная: текущий LSI, статус, вклад модулей
├─ pages/
│  ├─ 01_📊_Модули.py             # Графики по M1, M2, M3, M4, M5
│  ├─ 02_📉_Бэктест.py            # Стресс-эпизоды: дек.2014, фев-март 2022, авг.2023
│  └─ 03_🤖_Аналитик.py           # Автокомментарий + чат-RAG (LLM опционально)
├─ utils.py                        # Загрузка данных, алерты, цвета
├─ export_from_notebook.py         # Экспорт `wide_lsi` из ноутбука
├─ requirements.txt
└─ data/                           # сюда кладётся wide_lsi.csv / .parquet
```

## Установка

```bash
cd /Users/mayadzyuba/tryM4
python -m venv .venv && source .venv/bin/activate   # если ещё нет
pip install -r dashboard/requirements.txt
```

## Экспорт данных из ноутбука

В `final.ipynb` после обучения моделей (где формируется `wide_lsi` со столбцами `LSI_*`) добавьте ячейку:

```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "dashboard"))
from export_from_notebook import export_wide_lsi

export_wide_lsi(wide_lsi)   # запишет dashboard/data/wide_lsi.csv (+ parquet)
```

## Запуск

```bash
cd /Users/mayadzyuba/tryM4
streamlit run dashboard/app.py
```

По умолчанию приложение откроется на `http://localhost:8501`.

## Что есть

- **Главная (`app.py`)**: текущее значение LSI, статус 🟢🟡🔴, тренд за период, основной график с цветными зонами алертов и порогом 70, вклад модулей (по последним MAD/флагам), таблица последних 15 дней с цветным статусом.
- **Модули (`01_📊_Модули.py`)**: для каждого из M1–M5 — отдельная вкладка с временными рядами и MAD-сигналами.
- **Бэктест (`02_📉_Бэктест.py`)**: три обязательных эпизода из ТЗ + произвольный период; по каждому считаются пик LSI, дата пика, число дней 🔴 и 🟡.
- **Аналитик (`03_🤖_Аналитик.py`)**: текстовый автокомментарий (без LLM — структурный разбор по числам, с LLM — полноценный аналитический текст), чат-RAG по числам системы. Поддерживаются **DeepSeek** и **OpenAI** через один и тот же `openai`-клиент.

  **DeepSeek (по умолчанию, если задан ключ):**
  ```bash
  export DEEPSEEK_API_KEY=sk-...
  export DEEPSEEK_MODEL=deepseek-chat        # или deepseek-reasoner
  # export DEEPSEEK_BASE_URL=https://api.deepseek.com/v1   # дефолт
  ```

  **OpenAI:**
  ```bash
  export OPENAI_API_KEY=sk-...
  export OPENAI_MODEL=gpt-4o-mini
  ```

  Если заданы оба ключа, можно явно выбрать: `export LLM_PROVIDER=deepseek` (или `openai`).

## Пороговые значения алертов

Согласно ТЗ:

- 🟢 Зелёный — `0 ≤ LSI < 40`
- 🟡 Жёлтый — `40 ≤ LSI < 70`
- 🔴 Красный — `LSI ≥ 70`

Изменить можно в `dashboard/utils.py` → `LSI_THRESHOLDS`.

## Какую колонку LSI берём как «итоговую»

Дашборд автоматически выбирает первую доступную:

1. `LSI_lgbm_tuned_tax_adj`
2. `LSI_lgbm_tuned`
3. `LSI_ensemble_tax_adj`
4. `LSI_ensemble`
5. `LSI_lgbm_huber`
6. `LSI_teacher` (fallback)
